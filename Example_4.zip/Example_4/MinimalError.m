%-------  Fuction: Minimal Error method for  Example 3.1 -------%  

function [Vp G_Kk ]=MinimalError(DEL,G_Kk)
global N J2 T dt dx Na Nb Vexa tau E_K a C_M G_L E_L  G_K

%-------    Calculating ||a*Vexa+b||_L^2*DELTA        ---------%
delta=sqrt( dt*dx*sum ( sum( Vexa.^2 )  )  )*DEL;

%------     Making the pertubation of Vexa in Vp      ---------%
Vp = Vexa + (-DEL+2*DEL*rand(N,J2)).*(Na*Vexa+Nb);

%--------------------        k=========1         ---------------%
k=0;

while(k==0 || tau*delta<=ResiduoV)
 k=k+1;                               

%----------                Calculating  Vk, Uk         --------%
 b= 1 - 2*a - dt/C_M*G_L - dt/C_M*G_Kk;
 c= dt/C_M*G_L*E_L + dt/C_M*G_Kk*E_K  ;
 
 [Vk Uk]=Vkaprox(Vp,b,c)              ;

%----------    Calculing of the residue: ||Vp-Vk||      -------%
 ResiduoV=sqrt( dt*dx*[ sum(sum( (Vp -Vk )'.^2 ) )  ] ) ;

%----------       To the minimal error method            ------% 
 for i=1:J2
  adj(i)=1/T*dt* sum ( ( Vk(:,i)-E_K ).*Uk(:,i) );
 end
 if(max( abs( [adj] ) )==0)
   Wk=0;                                 end
 if(max( abs( [adj] ) )~=0)
 Wk=ResiduoV^2/( (max( abs( adj ) )) ^2); end  


%-----           Calculating the iteration k+1           -----%   
 G_Kk=G_Kk-Wk*adj/T;               
                                                
end 
