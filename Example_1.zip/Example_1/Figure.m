%%-----------------------------------------------------------------%%
%%                             Figures                             %%
%%                           Example 3.1                           %%
%%-----------------------------------------------------------------%%
 clc;close all;clear all                        

%--   j=1 => 25%,     j=2 => 5%,    j=3 => 1%,    j=4 => 0.2      --%  
j=3                     ;  
%%-----       To import Vexa, MVp, GK, GK1, t, x               -----%%
 M_V   = importdata(sprintf('Data%d/M_V.txt'  ,j)); 
 M_GK  = importdata(sprintf('Data%d/M_GK.txt' ,j));
 SD_V  = importdata(sprintf('Data%d/SD_V.txt' ,j));
 SD_GK = importdata(sprintf('Data%d/SD_GK.txt',j));
 Vexa  = importdata(sprintf('Data%d/Vexa.txt' ,j));
 GK    = importdata(sprintf('Data%d/GK.txt'   ,j));
 t     = importdata(sprintf('Data%d/t.txt'    ,j));
 x     = importdata(sprintf('Data%d/x.txt'    ,j));


%--------------- Figures of  Vexa and M_V   -----------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(t,Vexa(:,1),'r',t,Vexa(:,100),'b','LineWidth',1,'MarkerSize',6);
 xlabel('Time [ms]','fontsize',10);
 ylabel('V [mV]','fontsize',10);  
 title('Subplot A','fontsize',10)
 legend ({ 'V(t,0.1)', 'V(t,0)'  }, 'location','northwest','FontSize',8,'Orientation','horizontal' ); 
legend ( 'boxoff' )


 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(t,M_V(:,1),'r',t,M_V(:,100),'b','LineWidth',1,'MarkerSize',6);
 xlabel('Time [ms]','fontsize',10);
 ylabel('\mu_{V^\delta} [mV]','fontsize',10);  
 title('Subplot B','fontsize',10)
 legend ({ '\mu_{V^\delta(t,0.1)}', '\mu_{V^\delta(t,0)}'  }, 'location','northwest','FontSize',8,'Orientation','horizontal' ); 
legend ( 'boxoff' )

saveas(gcf,'Ex1-1.eps', 'psc2')

%------------- Figures of SD_V and Vexa-V_M  -------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(t,SD_V(:,1),'r',t,SD_V(:,100),'b','LineWidth',1,'MarkerSize',6);
 xlabel('Time [ms]','fontsize',10);
 ylabel('\sigma_{V^\delta} [mV]','fontsize',10);  
 title('Subplot C','fontsize',10)
 legend ({ '\sigma_{V^\delta(t,0.1)}', '\sigma_{V^\delta(t,0)}'  }, 'location','northwest','FontSize',8,'Orientation','horizontal' );
legend ( 'boxoff' )

 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(t,Vexa(:,1)-M_V(:,1),'r',t,Vexa(:,100)-M_V(:,100),'b','LineWidth',1,'MarkerSize',6);
 xlabel('Time [ms]','fontsize',10);
 ylabel('V-\mu_{V^\delta} [mV]','fontsize',10);  
 title('Subplot D','fontsize',10)
 legend ({ 'V(t,0.1)-\mu_{V^\delta(t,0.1)}', 'V(t,0)-\mu_{V^\delta(t,0)}'  }, 'location','northwest','FontSize',8 ,'Orientation','horizontal');
legend ( 'boxoff' )

saveas(gcf,'Ex1-2.eps', 'psc2')



%---------    Figures of GK and M_GK      ------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(x,GK,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K [mS/cm^2]','fontsize',10);
 ylim( [0.15 0.45] );
 title('Subplot A','fontsize',10)  
 

 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(x,M_GK,'b','LineWidth',1,'MarkerSize',8);
 xlabel('space [cm]','fontsize',10);
 ylabel('\mu_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 ylim( [0.15 0.45] );
 title('Subplot B','fontsize',10)

 saveas(gcf,'Ex1-3.eps', 'psc2')

%---------    Figures SD_GK and GK-M_GK    ----------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(x,SD_GK,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('\sigma_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 title('Subplot C','fontsize',10)  

 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(x,GK-M_GK,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K-\mu_{{G_K^{k_*,\delta}}} [mS/cm^2]','fontsize',10);  
 title('Subplot D','fontsize',10)

 saveas(gcf,'Ex1-4.eps', 'psc2')


