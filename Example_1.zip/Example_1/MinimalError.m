%-------  Fuction: Minimal Error method for  Example 3.1 -------%  


function [Vp G_Kk ]=MinimalError(DEL,G_Kk)
global N J T dt dx Na Nb Vexa tau E_K a_1 a_2 G_Na
 
%-------    Calculating ||a*Vexa+b||_L^2*DELTA        ---------%
if(a_1==1)
delta=sqrt( dt*dx*[ sum(sum( ( Na*Vexa+Nb )'.^2 ) )  ] )*DEL; end
                                                       
if(a_2==1)                                             
delta=sqrt( dt*[ sum( ( Na*Vexa(:,1)+Nb )'.^2 ) + ...     
                 sum( ( Na*Vexa(:,J)+Nb )'.^2 ) ] )*DEL;      end
 
%-------      Making the pertubation of Vexa in Vp     --------%
Vp=Vexa + ( -DEL+2*DEL.*rand(N,J) ).*(Na*Vexa+Nb); 

%%------                k=========1                    --------%
k=0;

while(k==0 || tau*delta<=ResiduoV) 
k=k+1;                               
%-----              Calculating  Vk, Uk               -----%
  [Vk Uk]=VsoluI(G_Kk,G_Na,Vp);
  
%-----   Calculing of the residue: ||Vp-Vk||         ------%
  if(a_1==1)
    ResiduoV=sqrt( dt*dx*[ sum(sum( (Vp -Vk )'.^2 ) )  ] ) ; 
  end

  if(a_2==1) 
    ResiduoV=sqrt( dt*[ sum( (Vp(:,1) -Vk(:,1) )'.^2 ) + ...
                      sum( (Vp(:,J)-Vk(:,J))'.^2 ) ] );   end

  
%-----       To the minimal error method             ------%
 for i=1:J
   adj_K(i)=1/T*dt*sum ( ( Vk(:,i)-E_K ).*Uk(:,i) ); 
 end
  
 if(max( abs(adj_K) )==0)
   Wk=0;                                 end
 if(max( abs(adj_K) )~=0)               
   Wk=ResiduoV^2/(max( abs(adj_K) ) )^2; end
  
  
%-----        Calculating the iteration k+1         ------%
  G_Kk=G_Kk -Wk*adj_K/T;
end
