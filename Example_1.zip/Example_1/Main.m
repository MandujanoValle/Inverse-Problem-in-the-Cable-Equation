%%%%%%%%      To understand the code read article     %%%%%%%%%%%%
%%     A COMPUTATIONAL APPROACH FOR THE INVERSE PROBLEM OF      %% 
%%             NEURAL CONDUCTANCES DETERMINATION                %%
%%                       Example 3.1                            %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all;clear all 

global N J L T N_E a b c p q r E_K E_Na E_L G_L a_1 a_2  R ...
       ra G_K Vexa dt dx  Na Nb G_Na G_L tau
                                                                  
%%%%%%%%%%%         Start: defining PDE      %%%%%%%%%%%%%%%%%%%%|
                                                                %|
%---             Set the intervals  [0 T] [0 L]              ---%|
L=0.1;    J=100;    x=linspace(0,L,J);   dx = x(2)-x(1);        %|
T=20;     N=100;    t=linspace(0,T,N);   dt = t(2)-t(1);        %|
                                                                %|
%---                Information of V                         ---%|
a_1=0;   a_2=1;  %% a_1: all of "V",  a_2: Border of "V"        %|
                                                                %|
%---                  Noise of V                             ---%|
Na=1/2; Nb=1/2;   %% Na: Multiplicate noise, Nb: Additive noise,%|
                                                                %|
%---               Set the parameters                        ---%|
ra=0.0238; R=35.4; C_M=1; E_K=-12; E_Na=115; E_L=10.6;          %|
                                                                %|
%---                Inicial Condition                        ---%|
r=0*x;                                                          %|
                                                                %|
%---                Boundary condition                       ---%|
p=-R/(pi*(ra)^2)*t.^2.*exp(-10*t);   q=0*t;                     %|
                                                                %|
%---                   Conductances                          ---%|
G_Na = 0*x;                                                     %|
G_L  = 0.3;                                                     %|
                                                                %|
%---                 Goal function (g_K)                     ---%|
G_K  = 0.2+0.2./( 1+exp( (0.1/2-x)/0.01 ) ) ;                 %|
                                                                %|
%---           Guess initial of Conductances                 ---%|
G_Kk =0*x;                                                      %|
                                                                %|
%---                For the stop criterion                   ---%|
tau =2.01;                                                      %|
                                                                %|
%---           Number of experiments                         ---%|
N_E=100;                                                        %|
                                                                %|
%%%%%%%%%-------             End              -------%%%%%%%%%%%%|
  
%-------           We denote the constants             ---------%   
a=ra*dt/(2*R*C_M*dx^2);  b=dt/C_M;   c=a*dx;

%-------         Calculating Vexa given  G_K           ---------%
[Vexa U] =VsoluI(G_K,G_Na,zeros(N,J));

%-------     Algorithm: Minimal Error method           ---------% 

for j=1:4

 %-------      DEL: Noise                              ---------%  
 DEL=25/(5^(j-1)*100);   
                        
 save(sprintf('Data%d/Vexa.txt',j),'Vexa', '-ascii' )
 save(sprintf('Data%d/GK.txt'  ,j),'G_K' , '-ascii' )
 save(sprintf('Data%d/t.txt'   ,j),'t'   , '-ascii' )
 save(sprintf('Data%d/x.txt'   ,j),'x'   , '-ascii' )
% G_Kk =0*x;

 for i=1:N_E
 G_Kk =0*x;

 %-------     Function: Minimal Error method          ---------% 
  [Vp G_Kk]=MinimalError(DEL,G_Kk);  
  save(sprintf('Data%d/Vp%d.txt',j,i) ,'Vp'   , '-ascii' )
  save(sprintf('Data%d/GK%d.txt',j,i) ,'G_Kk' , '-ascii' )

 end

 %-------     Function: Mean and Standard deviation   --------% 
 [M_V M_GK SD_V SD_GK]=mean_std(j);
 save( sprintf('Data%d/M_V.txt'  ,j) ,'M_V'   , '-ascii' ) 
 save( sprintf('Data%d/M_GK.txt' ,j) ,'M_GK'  , '-ascii' )
 save( sprintf('Data%d/SD_V.txt' ,j) ,'SD_V'  , '-ascii' )
 save( sprintf('Data%d/SD_GK.txt',j) ,'SD_GK' , '-ascii' )

 %-------     Function: Error for G_K and Vexa       --------%
 [ErroG ErroV]=Error(M_V,M_GK);

 %-------     Print of errors                        --------%
 fprintf('%10.4f\t\t',j,ErroG, ErroV);
 fprintf('\n\n'); 

end



