%-----  Fuction: Mean and Standard deviation for Example 3.2  -----%

function [M_V M_GK M_GNa SD_V SD_GK SD_GNa]=mean_std(j) 
global  N_E

%%-----   To calculate the Mean and Standard Deviation       -----%%
 M_V   = 0*importdata(sprintf('Data%d/Vp%d.txt' ,j,1));
 M_GK  = 0*importdata(sprintf('Data%d/GK%d.txt' ,j,1));
 M_GNa = 0*importdata(sprintf('Data%d/GNa%d.txt',j,1));

 SD_V  = 0*importdata(sprintf('Data%d/Vp%d.txt' ,j,1));
 SD_GK = 0*importdata(sprintf('Data%d/GK%d.txt' ,j,1));
 SD_GNa= 0*importdata(sprintf('Data%d/GNa%d.txt',j,1));

 for i=1:N_E
  M_V   =  M_V  + importdata(sprintf('Data%d/Vp%d.txt' ,j,i));
  M_GK  =  M_GK + importdata(sprintf('Data%d/GK%d.txt' ,j,i)); 
  M_GNa =  M_GNa+ importdata(sprintf('Data%d/GNa%d.txt',j,i)); 
 end

  M_V= M_V/N_E;  
  M_GK = M_GK/N_E;  
  M_GNa=M_GNa/N_E;

 for i=1:N_E
  SD_V   = SD_V   + ( M_V  - importdata(sprintf('Data%d/Vp%d.txt' ,j,i)) ).^2  ;
  SD_GK  = SD_GK  + ( M_GK - importdata(sprintf('Data%d/GK%d.txt' ,j,i)) ).^2  ;
  SD_GNa = SD_GNa + ( M_GNa- importdata(sprintf('Data%d/GNa%d.txt',j,i)) ).^2;
 end

 SD_V  = sqrt(SD_V/N_E); 
 SD_GK = sqrt(SD_GK/N_E); 
 SD_GNa= sqrt(SD_GNa/N_E);

