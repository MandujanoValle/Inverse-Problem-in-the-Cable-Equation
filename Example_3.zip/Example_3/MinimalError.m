%-------  Fuction: Minimal Error method for  Example 3.3 -------% 

function [Vp G_Kk G_Nak]=MinimalError(DEL,G_Kk,G_Nak)
global T N J dt dx Na Nb Vexa tau E_K E_Na

%-------          Calculating ||Vexa||_L^2             ---------%
delta=DEL*sqrt( dt*dx*sum ( sum( ( Na*Vexa+Nb )'.^2 )  )  );

%-------     Making the pertubation of Vexa in Vp      ---------%
Vp=Vexa + (-DEL+2*DEL.*rand(N,J)).*( Na*Vexa+Nb );

%---------                  k ====== 1             ------------%
k=0;

while(k==0 || tau*delta<=ResiduoV) 
k=k+1;                               
%-----              Calculating  Vk, Uk               -----%
  [Vk Uk]=VsoluI(G_Kk,G_Nak,Vp);

%-----   Calculing of the residue: ||Vp-Vk||        -------%
  ResiduoV=sqrt( dt*dx*[ sum(sum( (Vp -Vk )'.^2 ) )  ] );  
 
%-----       To the minimal error method             ------%
 for i=1:J
  adjK(i) =1/T*dt*sum ( ( Vk(:,i)-E_K  ).*Uk(:,i) );
  adjNa(i)=1/T*dt*sum ( ( Vk(:,i)-E_Na ).*Uk(:,i) );
 end
 
 if(max( abs( [adjK,adjNa] ) )==0)
   Wk=0;                                 end
 if(max( abs( [adjK,adjNa] ) )~=0)               
 %   Wk=ResiduoV^2/( max( abs( [adjK,adjNa] ) ) )^2; end
 Wk=ResiduoV^2/( (max( abs( adjK ) )) ^2+(max( abs( adjNa ) )) ^2); end

%-----        Calculating the iteration k+1           -----%
 G_Kk=G_Kk -Wk*adjK/T;   G_Nak=G_Nak-Wk*adjNa/T;

end

