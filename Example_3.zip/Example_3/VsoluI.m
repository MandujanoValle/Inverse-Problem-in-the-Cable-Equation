%-------  Fuction: Solution of V and U for  Example 3.1 -------%

function [V U]=VsoluI(G_K,G_Na,Vp)
global  N J a b c p q r E_K E_Na E_L G_L

%------------ Matrix A ------------%                                          
        A =zeros(J,J); 

for i=1:J-1
A(i,i+1) = -a;  A(i+1,i)= -a;    A(i+1,i+1) = 1+2*a+b*( G_K(i+1)+G_Na(i+1)+G_L );
end             
A(1,1)   = 1+a+b*( G_K(1)+G_Na(1)+G_L);    A(J,J) = 1+a+b*( G_K(J)+G_Na(J) +G_L);
A=inv(A);
%-------------- find V -------------%
B =zeros(N,J);                                            
B(:,1) =-c*p;          B(:,J)=c*q; 

V(1,:)=r; 

for n=1:N-1
V(n+1,:)=[ V(n,:) + b*( G_K*E_K + G_Na*E_Na + +G_L*E_L ) + B(n+1,:) ]*A;
end

%-------------- find U -------------%
U=zeros(N,J); 

D=Vp-V;

U(N,:)=0;
for n=1:N-1
U(N-n,:)=[ U(N-n+1,:)+b*D(N-n,:) ]*A;
end
