%-----     Fuction: Errors of G_K and Vexa for Example 3.2    -----%


function [ErroG ErroV]=Error(M_V,M_GK) 
global Vexa G_K T N L J 

%-----           Calculing the Error  for G_K          ------%
 for i=1:(N+1)/2
   for j=1:J
     if(G_K(i,j)==0)
       ErrorG(i,j)=abs(M_GK(i,j));end

     if(G_K(i,j)~=0)
       ErrorG(i,j)=abs( (G_K(i,j) -M_GK(i,j) )./G_K(i,j) );end
   end
 end

ErroG = T/(N+1)*L/J*sum(  sum ( ErrorG ) )*100;  

%-----           Calculing the Error  for Vexa          ------%
for i=1:(N+1)/2
  for j=1:J 
   if(Vexa(i,j)==0) 
     ErrorV(i,j)= abs( M_V(i,j) ); end

   if(Vexa(i,j)~=0)
     ErrorV(i,j)=abs( ( Vexa(i,j) -M_V(i,j) )./Vexa(i,j) );end
  end
end
 ErroV =T/(N+1)*L/J*sum( sum( (ErrorV) ) ) *100; 

%-----           Calculing the Error  for Vexa          ------%
%for i=1:(N+1)/2
%  for j=1:J 
%      ErrorV(i,j)= ( Vexa(i,j) -M_V(i,j) )^2 ;
%  end
%end
% ErroV =T/(N+1)*L/J*sqrt( sum( sum( (ErrorV) ) ) )*100; 
