%%%%%%%%      To understand the code read article     %%%%%%%%%%%%
%%     A COMPUTATIONAL APPROACH FOR THE INVERSE PROBLEM OF      %% 
%%             NEURAL CONDUCTANCES DETERMINATION                %%
%%                       Example 3.2                            %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all;clear all 
global T N L J dt dx Vv Uu E_K E_L G_L a b c p q r Vexa Na Nb tau N_E G_K      
                                                                  
%%%%%%%%%%%         Start: defining PDE      %%%%%%%%%%%%%%%%%%%%|
                                                                %|
%---             Set the iNervals  [0 T] [0 L]               ---%|
L=0.1;   J=100;    x=linspace(0,L,J);   dx = x(2)-x(1);         %|
T=40;    N=199;    t=linspace(0,T,N); dt = t(2)-t(1);           %|
                                                                %|
%---                  Noise of V                             ---%|
Na=1/2; Nb=1/2;   %% Na: Multiplicate noise, Nb: Additive noise %|
                                                                %|
%---               Set the parameters                        ---%|
ra=0.0238;  R=35.4;   C_M=1;   E_K=-12; E_L=10.6;               %|
                                                                %| 
%---                Inicial Condition                        ---%|
r=0*x;                                                          %|
                                                                %|
%---                Boundary condition                       ---%|
p=-0.1*R/(pi*(ra)^2)*t.^2.*exp(-10*t);   q=0*t;                 %|
                                                                %|
%---                               Guess initial                %|
[Xx,Tt]=meshgrid(x,t);  G_Kk=0*(Xx);                            %|
                                                                %|
%---                 Goal function (g_K)                     ---%|
G_K=1*(0.2+0.2./( 1+exp( (0.1/2-Xx)/0.01 ) ) ) + 0.05*(Tt);     %|
                                                                %| 
%---                   Conductances                          ---%|
G_L  = 0.3;                                                     %|
                                                                %|
%---                For the stop criterion                   ---%|
tau =1.01;                                                      %|
                                                                %|
%---           Number of experiments                         ---%|
N_E=50;                                                         %|
                                                                %|
%%%%%%%%%-------             End              -------%%%%%%%%%%%%|
  
%-------           We denote the constants             ---------%
a=ra*dt/(2*R*C_M*dx^2);  b=dt/C_M;     c=dx*a;
                        
%-------         Calculating Vexa given  G_K           ---------%
[Vexa U] =VsoluI(G_K,zeros(N,J));
 
%-------     Algorithm: Minimal Error method           ---------%  

for j=1:4
    
 %-------      DEL: Noise                              ---------%           
 DEL=25/(5^(j-1)*100);

 save(sprintf('Data%d/Vexa.txt',j),'Vexa', '-ascii' )
 save(sprintf('Data%d/GK.txt'  ,j),'G_K' , '-ascii' )
 save(sprintf('Data%d/t.txt'   ,j),'t'   , '-ascii' )
 save(sprintf('Data%d/x.txt'   ,j),'x'   , '-ascii' )
 %G_Kk=0*(Xx);

 for i=1:N_E
 G_Kk=0*(Xx);

 %-------     Function: Minimal Error method          ---------% 
  [Vp G_Kk]=MinimalError(DEL,G_Kk);  
  save(sprintf('Data%d/Vp%d.txt',j,i) ,'Vp'   , '-ascii' )
  save(sprintf('Data%d/GK%d.txt',j,i) ,'G_Kk' , '-ascii' )
 
 end

 %-------     Function: Mean and Standard deviation   --------% 
 [M_V M_GK SD_V SD_GK]=mean_std(j);
 save( sprintf('Data%d/M_V.txt'  ,j) ,'M_V'   , '-ascii' ) 
 save( sprintf('Data%d/M_GK.txt' ,j) ,'M_GK'  , '-ascii' )
 save( sprintf('Data%d/SD_V.txt' ,j) ,'SD_V'  , '-ascii' )
 save( sprintf('Data%d/SD_GK.txt',j) ,'SD_GK' , '-ascii' )


 %-------     Function: Error for G_K and Vexa       --------%
 [ErroG ErroV]=Error(M_V,M_GK);

 %-------     Print of errors                        --------%
 fprintf('%10.4f\t\t',5^(3-j),ErroG, ErroV);
 fprintf('\n\n'); 

end


