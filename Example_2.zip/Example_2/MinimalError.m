%-------  Fuction: Minimal Error method for  Example 3.2 -------%  

function [Vp G_Kk]=MinimalError(DEL,G_Kk)
global N J dt dx Na Nb Vexa tau E_K

%-------     Calculating ||a*Vexa+b||_L^2*DELTA        ---------%
delta=sqrt( dt*dx*sum ( sum( Vexa.^2 )  )  )*DEL;

%-------    Making the pertubation of Vexa in Vp       ---------%
Vp=Vexa + ( -DEL+2*DEL*rand(N,J) ).*(Na*Vexa+Nb);

%%-------               k=========1                    ---------%
k=0;   

while(k==0 || tau*delta<=ResiduoV) 
 k=k+1;                               
%-----              Calculating  Vk, Uk               -----%
 [Vk Uk]=VsoluI(G_Kk,Vp);
 
%-----   Calculing of the residue: ||Vp-Vk||        -------%
 ResiduoV=sqrt( dt*dx*[ sum(sum( (Vp -Vk )'.^2 ) )  ] ) ;

%-----       To the minimal error method             ------%
 adj=max(max( abs( (Vk-E_K).*Uk ) ));

 if(adj==0) 
   Wk=0;                 end
 if(adj~=0) 
   Wk=ResiduoV^2/adj^2;  end


%-----        Calculating the iteration k+1           -----%
 G_Kk=G_Kk -Wk*(Vk-E_K).*Uk;
                            
end
