%%-----------------------------------------------------------------%%
%%                             Figures                             %%
%%                           Example 3.2                           %%
%%-----------------------------------------------------------------%%
clc;close all;clear all
%%-----       To import Vexa, MVp, GK, GK1, t, x              -----%%
%--   j=1 => 25%,     j=2 => 5%,    j=3 => 1%,    j=4 => 0.2      --%  
for j=1:4;
i=5^(3-j);     if (i<1) i=0; end

%%-----       To import Vexa, MVp, GK, GK1, t, x               -----%%
 M_V   = importdata(sprintf('Data%d/M_V.txt'  ,j)); M_V  =M_V(1:100,:);
 M_GK  = importdata(sprintf('Data%d/M_GK.txt' ,j)); M_GK =M_GK(1:100,:);
 SD_V  = importdata(sprintf('Data%d/SD_V.txt' ,j)); SD_V =SD_V(1:100,:);
 SD_GK = importdata(sprintf('Data%d/SD_GK.txt',j)); SD_GK=SD_GK(1:100,:);
 Vexa  = importdata(sprintf('Data%d/Vexa.txt' ,j)); Vexa =Vexa(1:100,:);
 GK    = importdata(sprintf('Data%d/GK.txt'   ,j)); GK   =GK(1:100,:);
 t     = importdata(sprintf('Data%d/t.txt'    ,j)); t    =t(1:100);
 x     = importdata(sprintf('Data%d/x.txt'    ,j)); x    =x(1:100);
 
 [X,T]= meshgrid(x,t);

%--------------- Figures of  Vexa and M_V   -----------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,Vexa);
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('V [mV]','fontsize',10);
title('Subplot A','fontsize',10);
shading flat

subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10)
surf(X,T,M_V);
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('\mu_{V^\delta} [mV]','fontsize',10);
title('Subplot B ','fontsize',10);
shading flat

saveas(gcf,sprintf('Figures/%d_Percent/Fig1.eps',i), 'psc2')
%------------- Figures of SD_V and Vexa-V_M  -------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,SD_V );
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10); 
zlabel('\sigma_{V^\delta} [mV]','fontsize',10); 
title('Subplot C','fontsize',10);
shading flat

subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,Vexa-M_V );
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);  
zlabel('V-\mu_{V^\delta} [mV]','fontsize',10);
title('Subplot D','fontsize',10);
shading flat

saveas(gcf,sprintf('Figures/%d_Percent/Fig2.eps',i), 'psc2')

%---------    Figures of GK and M_GK      ------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,GK);
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('G_K [mS/cm^2]','fontsize',10);
shading flat;
title('Subplot A','fontsize',10);


subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,M_GK);
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('\mu_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
shading flat;
title('Subplot B','fontsize',10);

saveas(gcf,sprintf('Figures/%d_Percent/Fig3.eps',i), 'psc2')

%---------    Figures SD_GK and GK-M_GK    ----------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,SD_GK );
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10); 
zlabel('\sigma_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
shading flat;
title('Subplot C','fontsize',10)

subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X,T,GK-M_GK );
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);  
zlabel('G_K-\mu_{{G_K^{k_*,\delta}}} [mS/cm^2]','fontsize',10);
shading flat
title('Subplot D','fontsize',10)
saveas(gcf,sprintf('Figures/%d_Percent/Fig4.eps',i), 'psc2')

end
