%-------  Fuction: Solution of V and U for  Example 3.2 -------%

function [V U]=VsoluI(G_K,Vp)                                    
global  N J a b c p q r E_K E_L G_L

%------------ Matrix A ------------%                                          
A =zeros(J,J); 
for i=1:J-1
      A(i,i+1) = -a ;  A(i+1,i)= -a  ;  A(i+1,i+1) = 1+2*a;
end;  A(1,1)   = 1+a;  A(J,J) = 1+a;  

%-------------- find V -------------%
B =zeros(N,J);                                            
B(:,1) =-c*p;          B(:,J)=c*q; 

V(1,:)=r; 

for n=1:N-1
V(n+1,:)=[V(n,:)+b*(G_K(n+1,:)*E_K+E_L*G_L)+B(n+1,:)]*inv( A+b*diag(G_K(n+1,:)+G_L) );
end

%-------------- find U -------------%
U=zeros(N,J); 

D=Vp-V;


U(N,:)=[b*D(N,:)]*inv( A+b*diag( G_K(N,:)+G_L ) );
for n=1:N-1
U(N-n,:)=[U(N-n+1,:)+b*D(N-n,:)]*inv( A+b*diag( G_K(N-n,:)+G_L ) );
end

